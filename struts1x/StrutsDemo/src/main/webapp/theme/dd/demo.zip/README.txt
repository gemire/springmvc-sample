JQuery Accordion Plugin 

This plugin is free for any use. 
Feel free to adapt / improve it as well.

If you're using this plugin (and I know you are) I'd appreciate a link to my site or a small donation to paypal@i-marco.nl.

Copyright 2007-2010 by Marco van Hylckama Vlieg

http://www.i-marco.nl/weblog/
marco@i-marco.nl